package by.bsu.necklace.comparator;


import by.bsu.necklace.entity.JewelryStone;

import java.util.Comparator;


public class CostComparator implements Comparator<JewelryStone> {
    @Override
    public int compare(JewelryStone stone1, JewelryStone stone2) {
        return Math.negateExact(Integer.compare(stone1.getCost(), stone2.getCost()));
    }
}
