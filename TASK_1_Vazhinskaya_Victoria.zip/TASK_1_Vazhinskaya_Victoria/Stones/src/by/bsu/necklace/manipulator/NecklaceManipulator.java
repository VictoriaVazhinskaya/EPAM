package by.bsu.necklace.manipulator;

import by.bsu.necklace.comparator.CostComparator;
import by.bsu.necklace.entity.JewelryStone;
import by.bsu.necklace.entity.Necklace;
import by.bsu.necklace.maker.NecklaceMaker;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by Tory on 27.02.2016.
 */
public class NecklaceManipulator {
    private static final Logger logger = LogManager.getLogger(NecklaceManipulator.class);
        public static  int getTotalWeight(Necklace necklace){
        int totalWeight = 0;
        List<JewelryStone> stones = necklace.getStones();
        for(JewelryStone stone: stones){
           totalWeight += stone.getWeight();
        }
            logger.info("Total weight of stones is calculated");
        return  totalWeight;
    }
    public static int getTotalCost(Necklace necklace){
        int totalCost = 0;
        List<JewelryStone> stones = necklace.getStones();
        for(JewelryStone stone: stones){
            totalCost += stone.getCost();
        }
        logger.info("Total cost of stones is calculated");
        return  totalCost;
    }
    public static String getSortedByCostStones(Necklace necklace){
        List<JewelryStone> sortedByCostStones = new ArrayList<JewelryStone>(necklace.getStones());
        Collections.sort(sortedByCostStones, new CostComparator());
        Necklace dummyNecklace = new Necklace(sortedByCostStones);
        logger.info("Stones of the necklace are sorted");
        return dummyNecklace.toString();
    }
    public static  List<JewelryStone> findStonesOfSpecificDiaphaneity(Necklace necklace, String diaphaneity){
        List<JewelryStone> stones = necklace.getStones();
        List<JewelryStone> stonesOfSpecificDiaphaneity = new ArrayList<JewelryStone>();
        for(JewelryStone stone: stones){
            if(stone.getDiaphaneity().equalsIgnoreCase(diaphaneity)){
                stonesOfSpecificDiaphaneity.add(stone);
            }
        }
        logger.info("The stones of prescribed diaphaneity are found");
        return stonesOfSpecificDiaphaneity;
    }

}
