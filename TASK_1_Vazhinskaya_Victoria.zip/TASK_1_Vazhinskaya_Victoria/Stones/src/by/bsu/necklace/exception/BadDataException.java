package by.bsu.necklace.exception;


public class BadDataException extends Exception {
    public BadDataException() {
        super();
    }

    public BadDataException(String message) {
        super(message);
    }

    public BadDataException(String message, Throwable cause) {
        super(message, cause);
    }
}
