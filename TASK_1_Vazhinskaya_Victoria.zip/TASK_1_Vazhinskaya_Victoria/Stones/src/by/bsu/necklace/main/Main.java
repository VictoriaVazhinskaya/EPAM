package by.bsu.necklace.main;


import by.bsu.necklace.entity.Necklace;
import by.bsu.necklace.exception.BadDataException;
import by.bsu.necklace.maker.NecklaceMaker;
import by.bsu.necklace.manipulator.NecklaceManipulator;
import by.bsu.necklace.reporter.Reporter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


import java.io.*;


public class Main {
    private static final Logger logger;

    static {
        System.setProperty("log4j.configurationFile", new File("resources/log4j2.xml").getAbsolutePath());
        logger = LogManager.getLogger(Main.class);
    }

    public static void main(String[] args) {
        try {
            Necklace necklace = NecklaceMaker.makeNecklace("data/input.txt");
            PrintStream out = new PrintStream(new FileOutputStream("data/report.txt"));
            Reporter.report("all stones from necklace:\n" + necklace.toString(), System.out, out);
            Reporter.report("total weight:\n" + NecklaceManipulator.getTotalWeight(necklace) + "ctw", System.out, out);
            Reporter.report("total cost:\n" + NecklaceManipulator.getTotalCost(necklace) + "$", System.out, out);
            Reporter.report("sorted by cost stones:\n" + NecklaceManipulator.getSortedByCostStones(necklace), System.out, out);
            Reporter.report("all translucent stones:\n"
                    + new Necklace(NecklaceManipulator.findStonesOfSpecificDiaphaneity(necklace, "translucent")),
                    System.out, out);
        } catch (BadDataException|IOException e) {
            logger.error(e.getMessage());
        }
    }
}

