package by.bsu.necklace.reporter;

import java.io.PrintStream;

/**
 * Created by Tory on 27.02.2016.
 */
public class Reporter {
    public static void report(String data, PrintStream ... printStreams){
        for(int i=0; i<printStreams.length; i++)
        printStreams[i].println(data);
    }
}
