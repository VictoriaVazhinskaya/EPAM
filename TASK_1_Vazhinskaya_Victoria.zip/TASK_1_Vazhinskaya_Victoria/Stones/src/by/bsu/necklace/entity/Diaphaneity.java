package by.bsu.necklace.entity;

/**
 * Created by Tory on 24.02.2016.
 */
public enum Diaphaneity {
    TRANSPARENT,
    TRANSLUCENT,
    OPAQUE;

    public static String getStringForRegExp() {
        return "([Tt][Rr][Aa][Nn][Ss][Pp][Aa][Rr][Ee][Nn][Tt]|"
                + "[Tt][Rr][Aa][Nn][Ss][Ll][Uu][Cc][Ee][Nn][Tt]|"
                + "[Oo][Pp][Aa][Qq][Uu][Ee])";
    }
}
