package by.bsu.necklace.entity;

/**
 * Created by Tory on 25.02.2016.
 */
public enum Precious {
    PRECIOUS,
    SEMIPRECIOUS
}
