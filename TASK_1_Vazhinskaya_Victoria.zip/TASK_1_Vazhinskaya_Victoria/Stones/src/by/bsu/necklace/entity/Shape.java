package by.bsu.necklace.entity;

/**
 * Created by Tory on 27.02.2016.
 */
public enum Shape {
    SPHERICAL,
    OVAL,
    PEAR_SHAPED,
    BAROQUE;

    public static String getStringForRegExp() {
        return "([Ss][Pp][Hh][Ee][Rr][Ii][Cc][Aa][Ll]|[Oo][Vv][Aa][Ll]|"
                + "[Pp][Ea][Aa][Rr]_[Ss][Hh][Aa][Pp][Ee][Dd]|"
                + "[Bb][Aa][Rr][Oo][Qq][Uu][Ee])";
    }
}
