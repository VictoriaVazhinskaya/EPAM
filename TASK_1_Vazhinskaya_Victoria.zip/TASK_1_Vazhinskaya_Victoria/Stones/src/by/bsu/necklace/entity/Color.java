package by.bsu.necklace.entity;


public enum Color {
    PINK,
    RED,
    ORANGE,
    CHAMPAGNE,
    YELLOW,
    GREEN,
    TURQUOISE,
    BLUE,
    PURPLE,
    BROWN,
    BLACK,
    WHITE,
    COLORLESS;

    public static String getStringForRegExp() {
        return "([Pp][Ii][Nn][Kk]|[Rr][Ee][Dd]|[Oo][Rr][Aa][Nn][Gg][Ee]|"
                 + "[Cc][Hh][Aa][Mm][Pp][Aa][Gg][Nn][Ee]|"
                 + "[Yy][Ee][Ll]{2}[Oo][Ww]|[Gg][Rr][Ee]{2}[Nn]|"
                 + "[Tt][Uu][Rr][Qq][Uu][Oo][Ii][Ss][Ee]|"
                 + "[Bb][Ll][Uu][Ee]|[Pp][Uu][Rr][Pp][Ll][Ee]|"
                 + "[Bb][Rr][Oo][Ww][Nn]|[Bb][Ll][Aa][Cc][Kk]|"
                 + "[Cc][Oo][Ll][Oo][Rr][Ll][Ee][Ss]{2})";
    }
}
