package by.bsu.necklace.entity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class Necklace {
    private List<JewelryStone> stones;

    public Necklace(int capacity) {
        stones = new ArrayList<JewelryStone>(capacity);
    }

    public Necklace(List<JewelryStone> stones) {
        this.stones = new ArrayList<>(stones);
    }

    public boolean addStone(NecklaceTemplate necklaceTemplate, int position, JewelryStone stone) {
        if (necklaceTemplate.suits(position, stone)) {
            stones.add(stone);
            return true;
        }
        return false;
    }

    public List<JewelryStone> getStones() {
        return Collections.unmodifiableList(stones);
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < stones.size(); i++) {
            stringBuilder.append(stones.get(i).toString() + "\n");
        }
        return stringBuilder.toString();
    }
}
