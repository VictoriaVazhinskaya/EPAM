package by.bsu.necklace.entity;

import java.util.Collections;
import java.util.SortedMap;
import java.util.TreeMap;


public class NecklaceTemplate {
    private TreeMap<Integer, String> template;
    private int totalNumberOfStones;

    public NecklaceTemplate(String template) {
        this.template = new TreeMap<Integer, String>();
        String[] parts = template.split("&");
        int length = parts.length;
        for (int i = 0; i < length; i++) {
            this.template.putAll(pickOutData(parts[i]));
        }
        totalNumberOfStones = this.template.lastKey();
    }

    private TreeMap<Integer, String> pickOutData(String part) {
        TreeMap<Integer, String> positions = new TreeMap<Integer, String>();
        String[] data = part.trim().split("[\\W]+");
        String name = data[0].toLowerCase();
        if (part.contains("-") == true) {
            int position1 = Integer.parseInt(data[1]);
            int position2 = Integer.parseInt(data[2]);
            int start = Math.min(position1, position2);
            int end = Math.max(position1, position2);
            for (int i = start; i <= end; i++) {
                positions.put(i, name);
            }
        } else {
            int length = data.length;
            for (int i = 1; i < length; i++) {
                positions.put(Integer.parseInt(data[i]), name);
            }
        }
        return positions;
    }

    public int getTotalNumberOfStones() {
        return totalNumberOfStones;
    }

    public SortedMap<Integer, String> getTemplate() {
        return Collections.unmodifiableSortedMap(template);
    }

    public boolean emptyPosition(int position) {
        return Boolean.logicalXor(template.containsKey(position), true);
    }

    public boolean suits(int position, JewelryStone stone) {
        if (!emptyPosition(position)) {
            if (!template.get(position).equals(stone.getName())) {
                return false;
            }
        }
        return true;
    }
}
