package by.bsu.necklace.entity;

import by.bsu.necklace.validator.DefinitionOfStoneValidator;

import java.util.Scanner;


public class Pearl extends JewelryStone{
    Shape shape;
    public Pearl(String pearlDetails){
        super(Pearl.getStone(pearlDetails));
        Scanner scanner = new Scanner(pearlDetails);
        shape = Shape.valueOf(scanner.findInLine(Shape.getStringForRegExp()).toUpperCase());
    }

    public static boolean isPearl(String string){
        DefinitionOfStoneValidator validator = new DefinitionOfStoneValidator();
        if(validator.isValid(string)){
            return string.matches(".*" + Shape.getStringForRegExp() + "\\s*");
        }
        return  false;
    }
    @Override
    public String toString(){
        return super.toString() + ", shape: " + shape;
    }
}
