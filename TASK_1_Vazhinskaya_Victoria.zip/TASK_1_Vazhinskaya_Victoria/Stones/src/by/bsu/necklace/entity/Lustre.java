package by.bsu.necklace.entity;


public enum Lustre {
    ADAMANTINE,
    DULL,
    GREASY,
    METALLIC,
    PEARLY,
    RESINOUS,
    SILKY,
    SUBMETALLIC,
    VITREOUS,
    WAXY;

    public static String getStringForRegExp() {
        return "([Aa][Dd][Aa][Mm][Aa][Nn][Tt][Ii][Nn][Ee]|[Dd][Uu][Ll]{2}|"
                + "[Gg][Rr][Ee][Aa][Ss][Yy]|[Mm][Ee][Tt][Aa][Ll]{2}[Ii][Cc]|"
                + "[Pp][Ee][Aa][Rr][Ll][Yy]|[Rr][Ee][Ss][Ii][Nn][Oo][Uu][Ss]|"
                + "[Ss][Ii][Ll][Kk][Yy]|[Ss][Uu][Bb][Mm][Ee][Tt][Aa][Ll]{2}[Ii][Cc]|"
                + "[Vv][Ii][Tt][Rr][Ee][Oo][Uu][Ss]|[Ww][Aa][Xx][Yy])";
    }
}
