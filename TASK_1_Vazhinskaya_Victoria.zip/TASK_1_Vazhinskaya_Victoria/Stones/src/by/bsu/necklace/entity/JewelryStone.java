package by.bsu.necklace.entity;

/**
 * Created by Tory on 24.02.2016.
 */
public class JewelryStone extends Stone {
    private Diaphaneity diaphaneity;
    private Lustre lustre;
    private int cost;
    private Precious preciousType;

    public JewelryStone(String name, double mohsScaleHardness, Color color, int weight,
                        Diaphaneity diaphaneity, Lustre lustre, int cost) {
        super(name, mohsScaleHardness, color, weight);
        this.diaphaneity = diaphaneity;
        this.lustre = lustre;
        this.cost = cost;
        preciousType = ((double) cost / weight > 1000) ? Precious.PRECIOUS : Precious.SEMIPRECIOUS;
    }

    public JewelryStone(final JewelryStone stone) {
        super(stone);
        this.diaphaneity = stone.diaphaneity;
        this.lustre = stone.lustre;
        this.cost = stone.cost;
        this.preciousType = stone.preciousType;
    }

    public static JewelryStone getStone(String stoneDetails) {
        String[] parts = stoneDetails.trim().split("[ ]+");
        String name = parts[0].toLowerCase();
        double mohsScaleHardness = Double.parseDouble(parts[1]);
        Color color = Color.valueOf(parts[2].toUpperCase());
        int weight = Integer.parseInt(parts[3]);
        Diaphaneity diaphaneity = Diaphaneity.valueOf(parts[4].toUpperCase());
        Lustre lustre = Lustre.valueOf(parts[5].toUpperCase());
        int cost = Integer.parseInt(parts[6]);
        return new JewelryStone(name, mohsScaleHardness, color, weight, diaphaneity, lustre, cost);
    }

    public String getDiaphaneity() {
        return diaphaneity.name();
    }

    public String getLustre() {
        return lustre.name();
    }

    public int getCost() {
        return cost;
    }

    public String getPreciousType() {
        return preciousType.name();
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder(super.toString());
        stringBuilder.append(", diaphaneity: " + diaphaneity);
        stringBuilder.append(", lustre: " + lustre);
        stringBuilder.append(", cost: " + cost);
        stringBuilder.append(", precious: " + preciousType);
        return stringBuilder.toString();
    }
}
