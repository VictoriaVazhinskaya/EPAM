package by.bsu.necklace.entity;

/**
 * Created by Tory on 24.02.2016.
 */
public abstract class Stone {
    protected String name;
    protected double mohsScaleHardness;
    protected Color color;
    protected int weight;

    public Stone(String name, double mohsScaleHardness, Color color, int weight) {
        this.name = name;
        this.mohsScaleHardness = mohsScaleHardness;
        this.color = color;
        this.weight = weight;
    }

    public Stone(final Stone stone) {
        this(stone.name, stone.mohsScaleHardness, stone.color, stone.weight);
    }

    public String getName() {
        return name;
    }

    public String getColor() {
        return color.name();
    }

    public int getWeight() {
        return weight;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public double getMohsScaleHardness() {
        return mohsScaleHardness;
    }

    public void setMohsScaleHardness(double mohsScaleHardness) {
        this.mohsScaleHardness = mohsScaleHardness;
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("name: " + name);
        stringBuilder.append(", mohsScaleHardness: " + mohsScaleHardness);
        stringBuilder.append(", color: " + color);
        stringBuilder.append(", weight: " + weight);
        return stringBuilder.toString();
    }
}
