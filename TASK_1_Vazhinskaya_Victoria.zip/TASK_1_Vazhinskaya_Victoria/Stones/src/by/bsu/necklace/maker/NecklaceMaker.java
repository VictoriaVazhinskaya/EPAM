package by.bsu.necklace.maker;

import by.bsu.necklace.entity.JewelryStone;
import by.bsu.necklace.entity.Necklace;
import by.bsu.necklace.entity.NecklaceTemplate;
import by.bsu.necklace.entity.Pearl;
import by.bsu.necklace.exception.BadDataException;
import by.bsu.necklace.validator.DefinitionOfStoneValidator;
import by.bsu.necklace.validator.NecklaceTemplateValidator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;

public class NecklaceMaker {
    private static final Logger logger = LogManager.getLogger(NecklaceMaker.class);

    public static Necklace makeNecklace(String filename) throws BadDataException, IOException {
        File file = new File(filename);
        if (!file.exists()) {
            throw new FileNotFoundException(filename + "is not found");
        }
        String readData;
        BufferedReader reader = new BufferedReader(new FileReader(file));
        NecklaceTemplateValidator ntValidator = new NecklaceTemplateValidator();

        if ((readData = reader.readLine()) != null) {
            if (!ntValidator.isValid(readData)) {
                throw new BadDataException("Unable to create an instance of NecklaceTemplate class: string '" +
                        readData + "' is incorrect");
            }
        }

        NecklaceTemplate necklaceTemplate = new NecklaceTemplate(readData);
        Necklace necklace = new Necklace(necklaceTemplate.getTotalNumberOfStones());
        int totalNumberOfStones = necklaceTemplate.getTotalNumberOfStones();
        int position = 1;
        DefinitionOfStoneValidator dosValidator = new DefinitionOfStoneValidator();
        while ((readData = reader.readLine()) != null && position <= totalNumberOfStones) {
            if (dosValidator.isValid(readData)) {
                JewelryStone stone = Pearl.isPearl(readData) ? new Pearl(readData) : JewelryStone.getStone(readData);
                if (necklace.addStone(necklaceTemplate, position, stone)) {
                    logger.info("The instance of class JewelryStone/Pearl '" + stone + "' is added to necklace");
                    position++;
                } else {
                    logger.info("The instance of class JewelryStone/Pearl '" + stone + "' is NOT added to necklace");
                }
            } else {
                logger.info("Unable to create an instance of JewelryStone/Pearl class: string '" + readData + "' is incorrect");
            }
        }
        return necklace;

    }

}
