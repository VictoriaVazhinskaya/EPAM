package by.bsu.necklace.validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class NecklaceTemplateValidator implements Validator {
    private final Pattern pattern = Pattern.compile("\\s*([a-zA-Z]+\\s*\\((\\s*(([1-9]+\\d*)(\\s*,\\s*([1-9]+\\d*))"
            + "*\\s*)|(\\s*([1-9]+\\d*)\\s*-\\s*([1-9]+\\d*))\\s*)\\)\\s*){1}(\\s*&\\s*[a-zA-Z]+\\s*"
            + "\\((\\s*(([1-9]+\\d*)(\\s*,\\s*([1-9]+\\d*))*\\s*)|(\\s*([1-9]+\\d*)\\s*-\\s*([1-9]+\\d*))\\s*)\\)\\s*)*\\s*");

    @Override
    public boolean isValid(String string) {
        Matcher matcher = pattern.matcher(string);
        return matcher.matches();
    }
}
