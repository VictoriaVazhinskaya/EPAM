package by.bsu.necklace.validator;

import by.bsu.necklace.entity.*;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class DefinitionOfStoneValidator implements Validator {
    private final Pattern pattern = Pattern.compile("\\s*[a-zA-Z]+\\s+(([1-9]{1}(\\.\\d+)?)|10)\\s+"
            + Color.getStringForRegExp() + "\\s+[1-9]+\\d*\\s+"
            + Diaphaneity.getStringForRegExp() + "\\s+"
            + Lustre.getStringForRegExp() + "\\s+[1-9]+\\d*(\\s+" + Shape.getStringForRegExp() + ")?\\s*");

    @Override
    public boolean isValid(String string) {
        Matcher matcher = pattern.matcher(string);
        return matcher.matches();

    }
}
