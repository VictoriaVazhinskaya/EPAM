package by.bsu.necklace.validator;


public interface Validator {
    boolean isValid(String string);
}
